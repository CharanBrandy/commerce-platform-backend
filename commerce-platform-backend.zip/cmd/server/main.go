
package main

import (
    "log"
    "net/http"

    "commerce/internal/api"
)

func main() {
    router := api.NewRouter()
    log.Println("Server running on :8080")
    http.ListenAndServe(":8080", router)
}
