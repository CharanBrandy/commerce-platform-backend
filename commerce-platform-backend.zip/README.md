# Commerce Platform Backend
Production-style Go backend with Postgres, Redis, Docker, GraphQL.
